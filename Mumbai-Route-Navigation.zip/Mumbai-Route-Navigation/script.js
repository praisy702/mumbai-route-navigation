/* =====================================================
   SMART MUMBAI ROUTE NAVIGATION
   FRONTEND ONLY
===================================================== */
 
 
/* =====================================================
   48 MUMBAI STATIONS
===================================================== */
 
const stations = [
 
    "CSMT",
    "Masjid",
    "Sandhurst Road",
    "Byculla",
    "Chinchpokli",
    "Currey Road",
    "Parel",
    "Dadar",
    "Matunga",
    "Sion",
    "Kurla",
    "Vidyavihar",
    "Ghatkopar",
    "Vikhroli",
    "Kanjurmarg",
    "Bhandup",
    "Nahur",
    "Mulund",
 
    "Wadala Road",
    "GTB Nagar",
    "Chunabhatti",
    "Tilak Nagar",
    "Chembur",
    "Govandi",
    "Mankhurd",
 
    "Reay Road",
    "Cotton Green",
 
    "Churchgate",
    "Marine Lines",
    "Charni Road",
    "Grant Road",
    "Mumbai Central",
    "Mahalaxmi",
    "Lower Parel",
    "Prabhadevi",
    "Matunga Road",
    "Mahim",
    "Bandra",
    "Khar Road",
    "Santacruz",
    "Vile Parle",
    "Andheri",
    "Jogeshwari",
    "Goregaon",
    "Malad",
    "Kandivali",
    "Borivali",
    "Dahisar"
 
];
 
 
 
/* =====================================================
   STATION ORDER
===================================================== */
 
const centralLine = [
 
    "CSMT",
    "Masjid",
    "Sandhurst Road",
    "Byculla",
    "Chinchpokli",
    "Currey Road",
    "Parel",
    "Dadar",
    "Matunga",
    "Sion",
    "Kurla",
    "Vidyavihar",
    "Ghatkopar",
    "Vikhroli",
    "Kanjurmarg",
    "Bhandup",
    "Nahur",
    "Mulund"
 
];
 
 
const harbourLine = [
 
    "CSMT",
    "Masjid",
    "Sandhurst Road",
    "Reay Road",
    "Cotton Green",
    "Wadala Road",
    "GTB Nagar",
    "Chunabhatti",
    "Kurla",
    "Tilak Nagar",
    "Chembur",
    "Govandi",
    "Mankhurd"
 
];
 
 
const westernLine = [
 
    "Churchgate",
    "Marine Lines",
    "Charni Road",
    "Grant Road",
    "Mumbai Central",
    "Mahalaxmi",
    "Lower Parel",
    "Prabhadevi",
    "Dadar",
    "Matunga Road",
    "Mahim",
    "Bandra",
    "Khar Road",
    "Santacruz",
    "Vile Parle",
    "Andheri",
    "Jogeshwari",
    "Goregaon",
    "Malad",
    "Kandivali",
    "Borivali",
    "Dahisar"
 
];
 
 
 
/* =====================================================
   DOM ELEMENTS
===================================================== */
 
const fromInput =
    document.getElementById("from");
 
const toInput =
    document.getElementById("to");
 
const routesContainer =
    document.getElementById("routesContainer");
 
const routeHeading =
    document.getElementById("routeHeading");
 
const routeDescription =
    document.getElementById("routeDescription");
 
const searchMessage =
    document.getElementById("searchMessage");
 
 
 
/* =====================================================
   LOAD STATION LIST
===================================================== */
 
const datalist =
    document.getElementById("stations");
 
 
stations.forEach(
    station => {
 
        const option =
            document.createElement("option");
 
        option.value =
            station;
 
        datalist.appendChild(option);
 
    }
);
 
 
 
/* =====================================================
   CURRENT ROUTES
===================================================== */
 
let currentRoutes = [];
 
 
 
/* =====================================================
   FIND STATION
===================================================== */
 
function findStation(name) {
 
    return stations.find(
        station =>
            station.toLowerCase() ===
            name.trim().toLowerCase()
    );
 
}
 
 
 
/* =====================================================
   GET LINE
===================================================== */
 
function getStationLines(station) {
 
    const lines = [];
 
 
    if (
        centralLine.includes(station)
    ) {
        lines.push("central");
    }
 
 
    if (
        harbourLine.includes(station)
    ) {
        lines.push("harbour");
    }
 
 
    if (
        westernLine.includes(station)
    ) {
        lines.push("western");
    }
 
 
    return lines;
 
}
 
 
 
/* =====================================================
   GET TRAIN DISTANCE
===================================================== */
 
function getTrainStops(from, to) {
 
    const possibleDistances = [];
 
 
    // Central line
    if (
        centralLine.includes(from) &&
        centralLine.includes(to)
    ) {
 
        const a =
            centralLine.indexOf(from);
 
        const b =
            centralLine.indexOf(to);
 
        possibleDistances.push(
            Math.abs(a - b)
        );
 
    }
 
 
    // Harbour line
    if (
        harbourLine.includes(from) &&
        harbourLine.includes(to)
    ) {
 
        const a =
            harbourLine.indexOf(from);
 
        const b =
            harbourLine.indexOf(to);
 
        possibleDistances.push(
            Math.abs(a - b)
        );
 
    }
 
 
    // Western line
    if (
        westernLine.includes(from) &&
        westernLine.includes(to)
    ) {
 
        const a =
            westernLine.indexOf(from);
 
        const b =
            westernLine.indexOf(to);
 
        possibleDistances.push(
            Math.abs(a - b)
        );
 
    }
 
 
    // Cross-line journey
    if (
        possibleDistances.length === 0
    ) {
 
        const fromLines =
            getStationLines(from);
 
        const toLines =
            getStationLines(to);
 
 
        // Central ↔ Western through Dadar
        if (
            (
                fromLines.includes("central") &&
                toLines.includes("western")
            ) ||
            (
                fromLines.includes("western") &&
                toLines.includes("central")
            )
        ) {
 
            const centralDistance =
                centralLine.includes(from)
                    ? Math.abs(
                        centralLine.indexOf(from) -
                        centralLine.indexOf("Dadar")
                    )
                    : Math.abs(
                        centralLine.indexOf(to) -
                        centralLine.indexOf("Dadar")
                    );
 
 
            const westernDistance =
                westernLine.includes(from)
                    ? Math.abs(
                        westernLine.indexOf(from) -
                        westernLine.indexOf("Dadar")
                    )
                    : Math.abs(
                        westernLine.indexOf(to) -
                        westernLine.indexOf("Dadar")
                    );
 
 
            possibleDistances.push(
                centralDistance +
                westernDistance +
                1
            );
 
        }
 
 
        // Central ↔ Harbour through Kurla
        if (
            (
                fromLines.includes("central") &&
                toLines.includes("harbour")
            ) ||
            (
                fromLines.includes("harbour") &&
                toLines.includes("central")
            )
        ) {
 
            const centralDistance =
                centralLine.includes(from)
                    ? Math.abs(
                        centralLine.indexOf(from) -
                        centralLine.indexOf("Kurla")
                    )
                    : Math.abs(
                        centralLine.indexOf(to) -
                        centralLine.indexOf("Kurla")
                    );
 
 
            const harbourDistance =
                harbourLine.includes(from)
                    ? Math.abs(
                        harbourLine.indexOf(from) -
                        harbourLine.indexOf("Kurla")
                    )
                    : Math.abs(
                        harbourLine.indexOf(to) -
                        harbourLine.indexOf("Kurla")
                    );
 
 
            possibleDistances.push(
                centralDistance +
                harbourDistance +
                1
            );
 
        }
 
 
        // Harbour ↔ Western
        if (
            (
                fromLines.includes("harbour") &&
                toLines.includes("western")
            ) ||
            (
                fromLines.includes("western") &&
                toLines.includes("harbour")
            )
        ) {
 
            const harbourDistance =
                harbourLine.includes(from)
                    ? Math.abs(
                        harbourLine.indexOf(from) -
                        harbourLine.indexOf("Wadala Road")
                    )
                    : Math.abs(
                        harbourLine.indexOf(to) -
                        harbourLine.indexOf("Wadala Road")
                    );
 
 
            const westernDistance =
                westernLine.includes(from)
                    ? Math.abs(
                        westernLine.indexOf(from) -
                        westernLine.indexOf("Dadar")
                    )
                    : Math.abs(
                        westernLine.indexOf(to) -
                        westernLine.indexOf("Dadar")
                    );
 
 
            possibleDistances.push(
                harbourDistance +
                westernDistance +
                3
            );
 
        }
 
    }
 
 
    if (
        possibleDistances.length === 0
    ) {
 
        return 10;
 
    }
 
 
    return Math.max(
        1,
        Math.min(...possibleDistances)
    );
 
}
 
 
 
/* =====================================================
   DISTANCE
===================================================== */
 
function calculateDistance(stops) {
 
    /*
       Approximate average Mumbai
       suburban station spacing.
    */
 
    return Math.max(
        0.8,
        stops * 1.55
    );
 
}
 
 
 
/* =====================================================
   TRAIN TIME
===================================================== */
 
function calculateTrainTime(stops) {
 
    return Math.max(
        6,
        Math.round(
            5 +
            (stops * 2.4)
        )
    );
 
}
 
 
 
/* =====================================================
   TRAIN FARE
===================================================== */
 
function calculateTrainFare(stops) {
 
    if (stops <= 2) return 5;
 
    if (stops <= 5) return 10;
 
    if (stops <= 10) return 15;
 
    if (stops <= 15) return 20;
 
    if (stops <= 20) return 25;
 
    return 30;
 
}
 
 
 
/* =====================================================
   METRO TIME
===================================================== */
 
function calculateMetroTime(
    distance,
    stops
) {
 
    return Math.max(
        10,
        Math.round(
            8 +
            distance * 2.7 +
            stops * 0.5
        )
    );
 
}
 
 
 
/* =====================================================
   METRO FARE
===================================================== */
 
function calculateMetroFare(distance) {
 
    if (distance <= 3) return 10;
 
    if (distance <= 6) return 20;
 
    if (distance <= 10) return 30;
 
    if (distance <= 15) return 40;
 
    if (distance <= 20) return 50;
 
    return 60;
 
}
 
 
 
/* =====================================================
   BUS TIME
===================================================== */
 
function calculateBusTime(distance) {
 
    return Math.max(
        15,
        Math.round(
            10 +
            
 
distance * 4.2
        )
    );
 
}
 
 
 
/* =====================================================
   BUS FARE
===================================================== */
 
function calculateBusFare(distance) {
 
    if (distance <= 3) return 10;
 
    if (distance <= 6) return 15;
 
    if (distance <= 10) return 20;
 
    if (distance <= 15) return 25;
 
    if (distance <= 20) return 30;
 
    return 35;
 
}
 
 
 
/* =====================================================
   WALKING TIME
===================================================== */
 
function calculateWalkingTime(distance) {
 
    return Math.max(
        8,
        Math.round(
            distance * 12
        )
    );
 
}
 
 
 
/* =====================================================
   TRANSFERS
===================================================== */
 
function calculateTransfers(
    from,
    to,
    type
) {
 
    if (type === "walk") {
        return 0;
    }
 
 
    const fromLines =
        getStationLines(from);
 
    const toLines =
        getStationLines(to);
 
 
    if (
        type === "train"
    ) {
 
        if (
            fromLines.some(
                line =>
                    toLines.includes(line)
            )
        ) {
 
            return 0;
 
        }
 
 
        return 1;
 
    }
 
 
    if (type === "metro") {
 
        return 1;
 
    }
 
 
    if (type === "bus") {
 
        return 0;
 
    }
 
 
    return 0;
 
}
 
 
 
/* =====================================================
   GENERATE ROUTES
===================================================== */
 
function generateRoutes(
    from,
    to
) {
 
    const stops =
        getTrainStops(
            from,
            to
        );
 
 
    const distance =
        calculateDistance(
            stops
        );
 
 
    const trainTime =
        calculateTrainTime(
            stops
        );
 
 
    const trainFare =
        calculateTrainFare(
            stops
        );
 
 
    const metroTime =
        calculateMetroTime(
            distance,
            stops
        );
 
 
    const metroFare =
        calculateMetroFare(
            distance
        );
 
 
    const busTime =
        calculateBusTime(
            distance
        );
 
 
    const busFare =
        calculateBusFare(
            distance
        );
 
 
    const walkingTime =
        calculateWalkingTime(
            distance
        );
 
 
    const routes = [
 
        {
            type: "train",
 
            icon: "🚆",
 
            title: "Local Train",
 
            subtitle:
                "Mumbai Suburban Railway",
 
            time: trainTime,
 
            fare: trainFare,
 
            distance: distance,
 
            stops: stops,
 
            transfers:
                calculateTransfers(
                    from,
                    to,
                    "train"
                ),
 
            walking:
                Math.max(
                    4,
                    Math.round(
                        distance * 0.15
                    )
                )
        },
 
 
        {
            type: "metro",
 
            icon: "🚇",
 
            title: "Metro",
 
            subtitle:
                "Mumbai Metro",
 
            time: metroTime,
 
            fare: metroFare,
 
            distance:
                Number(
                    (
                        distance * 1.08
                    ).toFixed(1)
                ),
 
            stops:
                Math.max(
                    2,
                    Math.round(
                        stops * 0.75
                    )
                ),
 
            transfers:
                calculateTransfers(
                    from,
                    to,
                    "metro"
                ),
 
            walking:
                Math.max(
                    5,
                    Math.round(
                        distance * 0.22
                    )
                )
        },
 
 
        {
            type: "bus",
 
            icon: "🚌",
 
            title: "BEST Bus",
 
            subtitle:
                "BEST Bus Service",
 
            time: busTime,
 
            fare: busFare,
 
            distance:
                Number(
                    (
                        distance * 1.18
                    ).toFixed(1)
                ),
 
            stops:
                Math.max(
                    3,
                    Math.round(
                        stops * 1.3
                    )
                ),
 
            transfers:
                0,
 
            walking:
                Math.max(
                    3,
                    Math.round(
                        distance * 0.12
                    )
                )
        },
 
 
        {
            type: "walk",
 
            icon: "🚶",
 
            title: "Walking",
 
            subtitle:
                "Walking Route",
 
            time: walkingTime,
 
            fare: 0,
 
            distance:
                Number(
                    (
                        distance * 1.15
                    ).toFixed(1)
                ),
 
            stops: 0,
 
            transfers: 0,
 
            walking:
                Math.round(
                    distance * 1.15
                )
        }
 
    ];
 
 
    return routes;
 
}
 
 
 
/* =====================================================
   FIND ROUTES
===================================================== */
 
function findRoutes() {
 
    const fromValue =
        fromInput.value.trim();
 
    const toValue =
        toInput.value.trim();
 
 
    const from =
        findStation(
            fromValue
        );
 
    const to =
        findStation(
            toValue
        );
 
 
    /* Validation */
 
    if (!from || !to) {
 
        searchMessage.innerHTML =
            "Please select valid Mumbai stations.";
 
        routesContainer.innerHTML = `
 
            <div class="error-card">
 
                <strong>
                    Invalid station
                </strong>
 
                <br>
 
                Please choose a station
                from the list of 48 Mumbai stations.
 
            </div>
 
        `;
 
        return;
 
    }
 
 
    if (
        from.toLowerCase() ===
        to.toLowerCase()
    ) {
 
        searchMessage.innerHTML =
            "Please select two different stations.";
 
        return;
 
    }
 
 
    /* Generate */
 
    currentRoutes =
        generateRoutes(
            from,
            to
        );
 
 
    /* Sort fastest */
 
    currentRoutes.sort(
        (a, b) =>
            a.time - b.time
    );
 
 
    /* Heading */
 
    routeHeading.innerHTML =
        `Routes from ${from} to ${to}`;
 
 
    routeDescription.innerHTML =
        `Estimated travel options • ${currentRoutes.length} modes available`;
 
 
    searchMessage.innerHTML =
        `✓ Routes found from ${from} to ${to}`;
 
 
    /* Display */
 
    displayRoutes(
        currentRoutes
    );
 
 
    /* Scroll */
 
    document
        .getElementById("routes")
        .scrollIntoView({
            behavior: "smooth"
        });
 
}
 
 
 
/* =====================================================
   DISPLAY ROUTES
===================================================== */
 
function displayRoutes(routes) {
 
    if (
        routes.length === 0
    ) {
 
        routesContainer.innerHTML = `
 
            <div class="empty-card">
 
                <div class="empty-icon">
                    🚫
                </div>
 
                <h3>
                    No routes available
                </h3>
 
            </div>
 
        `;
 
        return;
 
    }
 
 
    routesContainer.innerHTML =
        routes.map(
            (route, index) =>
                createRouteCard(
                    route,
                    index
                )
        ).join("");
 
}
 
 
 
/* =====================================================
   CREATE ROUTE CARD
===================================================== */
 
function createRouteCard(
    route,
    index
) {
 
    const fastest =
        index === 0;
 
 
    const fareText =
        route.fare === 0
            ? "Free"
            : `₹${route.fare}`;
 
 
    return `
 
        <div
            class="
                route-card
                ${fastest ? "fastest" : ""}
            "
        >
 
            ${
                fastest
                    ? `
                        <div class="fastest-label">
                            Fastest Route
                        </div>
                    `
                    : ""
            }
 
 
            <div class="route-top">
 
                <div class="transport-info">
 
                    <div class="transport-icon">
                        ${route.icon}
                    </div>
 
 
                    <div>
 
                        <h3>
                            ${route.title}
                        </h3>
 
                        <p>
                            ${route.subtitle}
                        </p>
 
                    </div>
 
                </div>
 
 
                <div class="duration">
                    ${route.time} min
                </div>
 
            </div>
 
 
 
            <div class="route-path">
 
                <span class="path-dot"></span>
 
                <span>
                    ${route.from || fromInput.value}
                </span>
 
                <span class="path-line"></span>
 
                <span>
                    ${route.to || toInput.value}
                </span>
 
                <span class="path-dot"></span>
 
            </div>
 
 
 
            <div class="route-details">
 
                <span>
                    💰
                    Fare:
                    <strong>
                        ${fareText}
                    </strong>
                </span>
 
 
                <span>
                    📍
                    Distance:
                    <strong>
                        ${route.distance} km
                    </strong>
                </span>
 
 
                <span>
                    🚉
                    Stops:
                    <strong>
                        ${route.stops}
                    </strong>
                </span>
 
 
                <span>
                    🔄
                    Changes:
                    <strong>
                        ${route.transfers}
                    </strong>
                </span>
 
            </div>
 
 
 
            <div class="route-bottom">
 
                <span class="source">
                    Frontend demo • Estimated time
                </span>
 
 
                <button
                    class="view-button"
                    onclick="viewRoute('${route.title}')"
                >
                    View Route
                </button>
 
            </div>
 
        </div>
 
    `;
 
}
 
 
 
/* =====================================================
   FILTER ROUTES
===================================================== */
 
function filterRoutes(type) {
 
    const filtered =
        currentRoutes.filter(
            route =>
                route.type === type
        );
 
 
    displayRoutes(
        filtered
    );
 
}
 
 
 
/* =====================================================
   SHOW ALL ROUTES
===================================================== */
 
function showAllRoutes() {
 
    displayRoutes(
        
 
[...currentRoutes]
    );
 
}
 
 
 
/* =====================================================
   SWAP STATIONS
===================================================== */
 
function swapStations() {
 
    const temp =
        fromInput.value;
 
    fromInput.value =
        toInput.value;
 
    toInput.value =
        temp;
 
}
 
 
 
/* =====================================================
   POPULAR LOCATION
===================================================== */
 
function selectPopular(
    station
) {
 
    if (
        !fromInput.value
    ) {
 
        fromInput.value =
            station;
 
        return;
 
    }
 
 
    if (
        !toInput.value
    ) {
 
        toInput.value =
            station;
 
        findRoutes();
 
        return;
 
    }
 
 
    fromInput.value =
        station;
 
}
 
 
 
/* =====================================================
   VIEW ROUTE
===================================================== */
 
function viewRoute(
    routeName
) {
 
    const route =
        currentRoutes.find(
            item =>
                item.title ===
                routeName
        );
 
 
    if (!route) {
        return;
    }
 
 
    alert(
 
        "ROUTE DETAILS\n\n" +
 
        `${route.title}\n\n` +
 
        `From: ${fromInput.value}\n` +
 
        `To: ${toInput.value}\n\n` +
 
        `Travel Time: ${route.time} minutes\n` +
 
        `Fare: ₹${route.fare}\n` +
 
        `Distance: ${route.distance} km\n` +
 
        `Stops: ${route.stops}\n` +
 
        `Changes: ${route.transfers}`
 
    );
 
}
 
 
 
/* =====================================================
   ENTER KEY SEARCH
===================================================== */
 
fromInput.addEventListener(
    "keydown",
    function(event) {
 
        if (
            event.key === "Enter"
        ) {
 
            findRoutes();
 
        }
 
    }
);
 
 
toInput.addEventListener(
    "keydown",
    function(event) {
 
        if (
            event.key === "Enter"
        ) {
 
            findRoutes();
 
        }
 
    }
);
 
 
 
/* =====================================================
   DEFAULT DEMO
===================================================== */
 
window.addEventListener(
    "DOMContentLoaded",
    function() {
 
        fromInput.value =
            "CSMT";
 
        toInput.value =
            "Dadar";
 
        findRoutes();
 
    }
);
 